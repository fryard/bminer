#!/bin/sh

# Change the following address to your BEAMaddr.
ADDRESS=de4d969d093c4dc8dedd41108cbc392f9719063eeb897a7d8ab4e4cac7915e07d9

USERNAME=$ADDRESS.w
POOL=beam.sparkpool.com:2222
SCHEME=beamhash3+ssl

./bminer -uri $SCHEME://$USERNAME@$POOL -api 127.0.0.1:1880
